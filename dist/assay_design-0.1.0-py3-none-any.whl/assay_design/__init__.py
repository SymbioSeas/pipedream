# assay_design/__init__.py

"""
Assay Design Package

A Python package for designing specific molecular assays targeting particular
taxa while excluding others.
"""

__version__ = '0.1.0'

# Import primary functions to expose at package level
from .data_retrieval import (
    fetch_sequence_by_accession,
    fetch_sequences_for_taxid,
    fetch_gene_sequences,
    get_taxon_info,
    get_related_taxa,
    suggest_marker_genes,
    load_local_fasta
)

# Import the optimized target identification function
from .target_identification import find_optimal_marker

# Import primer design functions
from .primer_design import design_primers, calculate_primer_properties

# Import specificity validation
from .specificity_validation import validate_primer_specificity

# Import CLI
from .cli import main

__all__ = [
    'fetch_sequence_by_accession',
    'fetch_sequences_for_taxid',
    'fetch_gene_sequences',
    'get_taxon_info',
    'get_related_taxa',
    'suggest_marker_genes',
    'load_local_fasta',
    'find_optimal_marker',
    'design_primers',
    'calculate_primer_properties',
    'validate_primer_specificity',
    'main'
]