# assay_design/cli.py

import argparse
import logging
import sys
import time
from typing import List, Optional

from .data_retrieval import (
    fetch_sequences_for_taxid,
    fetch_gene_sequences,
    get_related_taxa,
    suggest_marker_genes
)
# Import the optimized marker identification function
from .target_identification import find_optimal_marker
from .primer_design import design_primers
from .specificity_validation import validate_primer_specificity

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def create_parser():
    """Create an argument parser for the CLI."""
    parser = argparse.ArgumentParser(
        description='Design specific molecular assays for target organisms',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Design an assay for Vibrio mediterranei using automatic exclusion taxa
  assay-design --inclusion 689 --email user@example.com --auto-exclusion
  
  # Design an assay for a specific gene in Vibrio mediterranei
  assay-design --inclusion 689 --email user@example.com --gene "16S ribosomal RNA"
  
  # Get suggestions for marker genes for a taxon
  assay-design --inclusion 689 --email user@example.com --suggest-genes
  
  # Design with manual exclusion taxa
  assay-design --inclusion 689 --exclusion 717,670,672 --email user@example.com
"""
    )
    
    # Required arguments
    required = parser.add_argument_group('required arguments')
    required.add_argument(
        '--inclusion', 
        type=str, 
        required=True,
        help='NCBI taxid for the target organism'
    )
    required.add_argument(
        '--email', 
        type=str, 
        required=True,
        help='Your email for NCBI queries (required by NCBI)'
    )
    
    # Optional arguments
    parser.add_argument(
        '--exclusion', 
        type=str,
        help='NCBI taxids for non-target organisms (comma-separated)'
    )
    parser.add_argument(
        '--gene', 
        type=str,
        help='Specific gene target (e.g., "16S ribosomal RNA")'
    )
    parser.add_argument(
        '--auto-exclusion', 
        action='store_true',
        help='Automatically select related taxa for exclusion'
    )
    parser.add_argument(
        '--auto-exclusion-rank', 
        type=str,
        choices=['species', 'genus', 'family', 'order'],
        default='genus',
        help='Taxonomic rank for auto-exclusion (default: genus)'
    )
    parser.add_argument(
        '--auto-exclusion-count', 
        type=int,
        default=3,
        help='Number of taxa to auto-select for exclusion (default: 3)'
    )
    parser.add_argument(
        '--suggest-genes', 
        action='store_true',
        help='Suggest appropriate marker genes for the target'
    )
    parser.add_argument(
        '--max-runtime', 
        type=int,
        default=120,
        help='Maximum runtime in seconds for marker identification (default: 120)'
    )
    parser.add_argument(
        '--max-seq-length', 
        type=int,
        default=2000,
        help='Maximum sequence length to analyze (default: 2000)'
    )
    parser.add_argument(
        '--max-seq-count', 
        type=int,
        default=5,
        help='Maximum number of sequences to analyze per group (default: 5)'
    )
    parser.add_argument(
        '--output', 
        type=str,
        help='Output file for results (default: stdout)'
    )
    parser.add_argument(
        '--verbose', 
        action='store_true',
        help='Enable verbose output'
    )
    
    return parser

def main():
    """Main entry point for the CLI."""
    parser = create_parser()
    args = parser.parse_args()
    
    start_time = time.time()
    
    # Set verbosity
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Process inclusion taxid
    inclusion_taxid = args.inclusion
    logger.info(f"Target organism: taxid {inclusion_taxid}")
    
    # Process exclusion taxa
    exclusion_taxids = []
    if args.exclusion:
        exclusion_taxids = args.exclusion.split(',')
        logger.info(f"Manually specified exclusion taxa: {exclusion_taxids}")
    
    # Auto-generate exclusion taxa if requested
    if args.auto_exclusion:
        logger.info(f"Automatically selecting related taxa at rank '{args.auto_exclusion_rank}'")
        related_taxa = get_related_taxa(
            taxid=inclusion_taxid,
            email=args.email,
            relationship="sibling",
            rank=args.auto_exclusion_rank,
            max_results=args.auto_exclusion_count
        )
        
        for taxon in related_taxa:
            taxid = taxon.get("taxid")
            if taxid and taxid not in exclusion_taxids:
                exclusion_taxids.append(taxid)
                logger.info(f"Auto-selected exclusion taxon: {taxon.get('scientific_name')} (taxid: {taxid})")
    
    # Suggest genes if requested
    selected_gene = args.gene
    if args.suggest_genes:
        suggested_genes = suggest_marker_genes(inclusion_taxid, args.email)
        
        print("\nSuggested marker genes:")
        for i, gene_info in enumerate(suggested_genes, 1):
            print(f"{i}. {gene_info['gene']} - {gene_info['description']}")
        
        # Let user select a gene if none was provided
        if not selected_gene and suggested_genes:
            selection = input("\nSelect a gene number (or press Enter to skip): ")
            if selection.isdigit() and 1 <= int(selection) <= len(suggested_genes):
                selected_gene = suggested_genes[int(selection)-1]["gene"]
                print(f"Selected: {selected_gene}")
    
    # Set up the query term with gene if specified
    if selected_gene:
        logger.info(f"Using gene target: {selected_gene}")
    
    # Fetch sequences for inclusion taxid
    logger.info(f"Fetching sequences for inclusion taxid {inclusion_taxid}")
    inclusion_sequences = []
    try:
        if selected_gene:
            inclusion_sequences = fetch_gene_sequences(
                taxid=inclusion_taxid,
                gene_name=selected_gene,
                email=args.email,
                max_records=args.max_seq_count * 2  # Fetch more than needed for filtering
            )
        else:
            inclusion_sequences = fetch_sequences_for_taxid(
                taxid=inclusion_taxid,
                email=args.email,
                max_records=args.max_seq_count * 2
            )
        
        logger.info(f"Retrieved {len(inclusion_sequences)} sequences for inclusion taxid")
        
        if not inclusion_sequences:
            logger.error(f"No sequences found for taxid {inclusion_taxid}" + 
                        (f" with gene {selected_gene}" if selected_gene else ""))
            sys.exit(1)
            
    except Exception as e:
        logger.error(f"Error fetching inclusion sequences: {e}")
        sys.exit(1)
    
    # Fetch sequences for exclusion taxids
    logger.info(f"Fetching sequences for {len(exclusion_taxids)} exclusion taxids")
    exclusion_sequences = []
    
    for taxid in exclusion_taxids:
        try:
            sequences = []
            if selected_gene:
                sequences = fetch_gene_sequences(
                    taxid=taxid,
                    gene_name=selected_gene,
                    email=args.email,
                    max_records=args.max_seq_count
                )
            else:
                sequences = fetch_sequences_for_taxid(
                    taxid=taxid,
                    email=args.email,
                    max_records=args.max_seq_count
                )
                
            exclusion_sequences.extend(sequences)
            logger.info(f"Retrieved {len(sequences)} sequences for exclusion taxid {taxid}")
        except Exception as e:
            logger.error(f"Error fetching exclusion sequences for taxid {taxid}: {e}")
    
    # Find conserved markers using the optimized method
    logger.info("Identifying conserved marker regions")
    marker_info = find_optimal_marker(
        inclusion_sequences, 
        exclusion_sequences,
        timeout_seconds=args.max_runtime
    )
    
    if "error" in marker_info:
        logger.error(f"Failed to identify a suitable marker region: {marker_info['error']}")
        sys.exit(1)
    
    # Use a basic placeholder for primer design
    marker_for_primer_design = {
        "marker_region_start": 0,
        "marker_region_end": marker_info.get("marker_length", 0) - 1,
        "marker_sequence": marker_info.get("marker_sequence", ""),
        "conservation_score": marker_info.get("conservation_score", 0),
    }
    
    # Design primers for the marker region
    logger.info("Designing primers for the identified marker region")
    primers = design_primers(marker_for_primer_design)
    
    # Validate primer specificity
    logger.info("Validating primer specificity")
    validation_results = validate_primer_specificity(
        primers, 
        inclusion_taxid, 
        exclusion_taxids,
        email=args.email
    )
    
    # Format and output results
    results = format_results(
        inclusion_taxid=inclusion_taxid,
        gene=selected_gene,
        exclusion_taxids=exclusion_taxids,
        marker_info=marker_info,
        primers=primers,
        validation_results=validation_results,
        runtime=time.time() - start_time
    )
    
    # Output results
    if args.output:
        with open(args.output, 'w') as f:
            f.write(results)
        logger.info(f"Results written to {args.output}")
    else:
        print("\n" + results)
    
    return 0

def format_results(
    inclusion_taxid: str,
    gene: Optional[str],
    exclusion_taxids: List[str],
    marker_info: dict,
    primers: List[dict],
    validation_results: dict,
    runtime: float
) -> str:
    """Format the results as a string."""
    lines = ["=== Assay Design Results ===", ""]
    
    lines.append(f"Target: Taxid {inclusion_taxid}")
    if gene:
        lines.append(f"Target gene: {gene}")
    
    lines.append(f"Exclusion taxa: {', '.join(exclusion_taxids)}")
    lines.append(f"Total runtime: {runtime:.2f} seconds")
    
    lines.append("\nIdentified marker region:")
    lines.append(f"Length: {marker_info.get('marker_length')}")
    lines.append(f"Conservation score: {marker_info.get('conservation_score', 0):.2f}")
    if 'specificity_score' in marker_info:
        lines.append(f"Specificity score: {marker_info.get('specificity_score', 0):.2f}")
    lines.append(f"Description: {marker_info.get('description')}")
    
    # Only show part of the marker sequence if it's long
    marker_seq = marker_info.get('marker_sequence', '')
    if len(marker_seq) > 100:
        lines.append(f"Marker sequence (first 50 bp): {marker_seq[:50]}...")
        lines.append(f"Marker sequence (last 50 bp): ...{marker_seq[-50:]}")
    else:
        lines.append(f"Marker sequence: {marker_seq}")
    
    lines.append("\nDesigned primers:")
    for i, primer in enumerate(primers, 1):
        lines.append(f"Primer {i} ({primer.get('orientation', 'unknown')}):")
        lines.append(f"  Sequence: {primer.get('sequence', '')}")
        
        properties = primer.get('properties', {})
        if properties:
            lines.append(f"  Length: {properties.get('length', 0)}")
            lines.append(f"  GC Content: {properties.get('gc_content', 0):.1f}%")
            lines.append(f"  Tm: {properties.get('tm', 0):.1f}°C")
    
    lines.append("\nSpecificity validation:")
    if "error" in validation_results:
        lines.append(f"Error: {validation_results.get('error')}")
    else:
        lines.append(f"Specificity score: {validation_results.get('specificity_score', 0):.2f}")
        
        if validation_results.get('inclusion_hits'):
            lines.append("\nExpected amplification in target:")
            for hit in validation_results.get('inclusion_hits', []):
                lines.append(f"  {hit.get('organism')} - Product size: {hit.get('product_size')} bp")
        
        if validation_results.get('exclusion_hits'):
            lines.append("\nPotential cross-reactivity:")
            for hit in validation_results.get('exclusion_hits', []):
                lines.append(f"  {hit.get('organism')} - Product size: {hit.get('product_size')} bp")
        
        if validation_results.get('potential_issues'):
            lines.append("\nPotential issues:")
            for issue in validation_results.get('potential_issues', []):
                lines.append(f"  - {issue}")
    
    return "\n".join(lines)

if __name__ == "__main__":
    sys.exit(main())