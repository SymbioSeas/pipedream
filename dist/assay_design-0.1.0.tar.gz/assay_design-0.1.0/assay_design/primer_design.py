# assay_design/primer_design.py

import logging
import re
from typing import List, Dict, Any, Union
from Bio.SeqUtils import MeltingTemp as mt
from Bio.Seq import Seq

logger = logging.getLogger(__name__)

def calculate_primer_properties(sequence: str) -> Dict[str, Any]:
    """
    Calculate key properties of a potential primer sequence.
    
    Args:
        sequence (str): Primer sequence
        
    Returns:
        Dict[str, Any]: Dictionary of primer properties
    """
    seq = Seq(sequence)
    properties = {
        "length": len(sequence),
        "gc_content": calculate_gc_content(sequence),
        "tm": mt.Tm_Wallace(sequence),  # Basic melting temp calculation
        "self_complementarity": check_self_complementarity(sequence),
        "has_repeats": has_repeats(sequence),
        "end_stability": check_3prime_stability(sequence)
    }
    return properties

def calculate_gc_content(sequence: str) -> float:
    """Calculate GC content of a sequence."""
    sequence = sequence.upper()
    gc_count = sequence.count('G') + sequence.count('C')
    return round((gc_count / len(sequence)) * 100, 2) if len(sequence) > 0 else 0

def check_self_complementarity(sequence: str) -> float:
    """
    Check for self-complementarity in a primer sequence.
    Returns a score where higher values indicate more self-complementarity.
    """
    # Simple implementation - more sophisticated algorithms would be used in production
    seq = sequence.upper()
    rev_comp = str(Seq(seq).reverse_complement())
    
    max_complementary = 0
    for i in range(len(seq)):
        match_count = 0
        for j in range(min(len(seq) - i, len(rev_comp))):
            if seq[i + j] == rev_comp[j]:
                match_count += 1
            else:
                match_count = 0
            max_complementary = max(max_complementary, match_count)
    
    return max_complementary

def has_repeats(sequence: str, max_repeat: int = 4) -> bool:
    """Check for nucleotide repeats in a primer sequence."""
    for base in "ATGC":
        if base * max_repeat in sequence.upper():
            return True
    return False

def check_3prime_stability(sequence: str, window: int = 5) -> float:
    """
    Calculate 3' end stability of a primer.
    Lower values are more stable (better for primer specificity).
    """
    if len(sequence) < window:
        return 0
    
    # Get the 3' end subsequence
    three_prime = sequence[-window:].upper()
    
    # Count GC content at 3' end as a simple stability measure
    gc_count = three_prime.count('G') + three_prime.count('C')
    return gc_count / window

def design_primers_for_sequence(
    sequence: str,
    min_length: int = 18, 
    max_length: int = 27,
    min_tm: float = 55.0,
    max_tm: float = 65.0,
    min_gc: float = 40.0,
    max_gc: float = 60.0,
    num_candidates: int = 5
) -> List[Dict[str, Any]]:
    """
    Design primers for a given marker sequence.
    
    Args:
        sequence (str): The marker sequence
        min_length (int): Minimum primer length
        max_length (int): Maximum primer length
        min_tm (float): Minimum melting temperature
        max_tm (float): Maximum melting temperature
        min_gc (float): Minimum GC content percentage
        max_gc (float): Maximum GC content percentage
        num_candidates (int): Number of candidate primers to return
        
    Returns:
        List[Dict[str, Any]]: List of candidate primers with properties
    """
    logger.info(f"Designing primers for sequence of length {len(sequence)}")
    
    # Set reasonable defaults if sequence is too short
    if len(sequence) < 100:
        min_length = max(15, min_length)
        max_length = min(len(sequence) // 3, max_length)
        logger.info(f"Adjusted primer length range to {min_length}-{max_length} for short sequence")
    
    forward_candidates = []
    reverse_candidates = []
    
    # Generate forward primer candidates from the beginning of the sequence
    forward_region = sequence[:min(100, len(sequence) // 2)]
    
    for length in range(min_length, min(max_length + 1, len(forward_region) + 1)):
        for start in range(0, min(20, len(forward_region) - length + 1)):
            primer_seq = forward_region[start:start + length]
            properties = calculate_primer_properties(primer_seq)
            
            # Check if primer meets criteria
            if (min_gc <= properties["gc_content"] <= max_gc and
                min_tm <= properties["tm"] <= max_tm and
                not properties["has_repeats"] and
                properties["self_complementarity"] <= 4):
                
                forward_candidates.append({
                    "sequence": primer_seq,
                    "properties": properties,
                    "position": start,
                    "orientation": "forward",
                    "score": calculate_primer_score(properties)
                })
    
    # Generate reverse primer candidates from the end of the sequence
    reverse_region = sequence[max(0, len(sequence) - 100):]
    reverse_comp = str(Seq(reverse_region).reverse_complement())
    
    for length in range(min_length, min(max_length + 1, len(reverse_region) + 1)):
        for start in range(0, min(20, len(reverse_region) - length + 1)):
            primer_seq = reverse_comp[start:start + length]
            properties = calculate_primer_properties(primer_seq)
            
            # Check if primer meets criteria
            if (min_gc <= properties["gc_content"] <= max_gc and
                min_tm <= properties["tm"] <= max_tm and
                not properties["has_repeats"] and
                properties["self_complementarity"] <= 4):
                
                reverse_candidates.append({
                    "sequence": primer_seq,
                    "properties": properties,
                    "position": len(sequence) - start - length,
                    "orientation": "reverse",
                    "score": calculate_primer_score(properties)
                })
    
    # Sort candidates by score
    forward_candidates.sort(key=lambda x: x["score"], reverse=True)
    reverse_candidates.sort(key=lambda x: x["score"], reverse=True)
    
    logger.info(f"Generated {len(forward_candidates)} forward and {len(reverse_candidates)} reverse primer candidates")
    
    # Take the best candidates
    best_forward = forward_candidates[:num_candidates] if forward_candidates else []
    best_reverse = reverse_candidates[:num_candidates] if reverse_candidates else []
    
    # If we couldn't find primers that meet all criteria, create basic ones
    if not best_forward:
        logger.warning("No good forward primers found, creating basic primer")
        primer_seq = sequence[:min(20, len(sequence) // 3)]
        best_forward = [{
            "sequence": primer_seq,
            "properties": calculate_primer_properties(primer_seq),
            "position": 0,
            "orientation": "forward",
            "score": 0.5
        }]
    
    if not best_reverse:
        logger.warning("No good reverse primers found, creating basic primer")
        rev_seq = str(Seq(sequence[-min(20, len(sequence) // 3):]).reverse_complement())
        best_reverse = [{
            "sequence": rev_seq,
            "properties": calculate_primer_properties(rev_seq),
            "position": len(sequence) - min(20, len(sequence) // 3),
            "orientation": "reverse",
            "score": 0.5
        }]
    
    # Return best primers
    return best_forward + best_reverse

def calculate_primer_score(properties: Dict[str, Any]) -> float:
    """
    Calculate an overall score for a primer based on its properties.
    
    Args:
        properties (Dict[str, Any]): Primer properties
        
    Returns:
        float: Score between 0 and 1 (higher is better)
    """
    # Optimal values
    optimal_gc = 50
    optimal_tm = 60
    optimal_length = 22
    
    # Calculate component scores
    gc_score = 1.0 - abs(properties["gc_content"] - optimal_gc) / 40
    tm_score = 1.0 - abs(properties["tm"] - optimal_tm) / 15
    length_score = 1.0 - abs(properties["length"] - optimal_length) / 15
    complementarity_score = 1.0 - properties["self_complementarity"] / 8
    
    # Weight the components
    score = (
        0.3 * gc_score +
        0.3 * tm_score +
        0.2 * length_score +
        0.2 * complementarity_score
    )
    
    return max(0, min(1, score))

def design_primers(marker_info: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Design primers for a specified marker region.
    
    Args:
        marker_info (Dict[str, Any]): Information about the marker region
        
    Returns:
        List[Dict[str, Any]]: List of designed primers with properties
    """
    # Extract the marker sequence
    marker_sequence = marker_info.get("marker_sequence", "")
    
    if not marker_sequence:
        logger.error("No marker sequence provided for primer design")
        # Return placeholder primers
        return [
            {
                "name": "Forward_Primer",
                "sequence": "ATGCGTACGTACGTACG",
                "properties": calculate_primer_properties("ATGCGTACGTACGTACG"),
                "position": 0,
                "orientation": "forward"
            },
            {
                "name": "Reverse_Primer",
                "sequence": "ACGTACGTACGTACGCAT",
                "properties": calculate_primer_properties("ACGTACGTACGTACGCAT"),
                "position": len(marker_sequence) - 18 if len(marker_sequence) >= 18 else 0,
                "orientation": "reverse"
            }
        ]
    
    # Design primers for the marker sequence
    primers = design_primers_for_sequence(marker_sequence)
    
    # Find the best primer pair
    primer_pair = optimize_primer_pair(primers)
    
    # Assemble final primer list
    final_primers = []
    
    if primer_pair.get("forward_primer"):
        forward = primer_pair["forward_primer"]
        forward["name"] = "Forward_Primer"
        final_primers.append(forward)
    
    if primer_pair.get("reverse_primer"):
        reverse = primer_pair["reverse_primer"]
        reverse["name"] = "Reverse_Primer"
        final_primers.append(reverse)
    
    return final_primers

def optimize_primer_pair(primers: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Optimize a set of primers to ensure they work well together.
    
    Args:
        primers (List[Dict[str, Any]]): List of primer candidates
        
    Returns:
        Dict[str, Any]: Optimized primer pair information
    """
    # Separate forward and reverse primers
    forward_primers = [p for p in primers if p.get("orientation") == "forward"]
    reverse_primers = [p for p in primers if p.get("orientation") == "reverse"]
    
    if not forward_primers or not reverse_primers:
        logger.warning("Not enough primers to form a pair")
        return {
            "forward_primer": forward_primers[0] if forward_primers else None,
            "reverse_primer": reverse_primers[0] if reverse_primers else None,
            "product_size": 150,  # Placeholder
            "compatibility_score": 0.5  # Placeholder
        }
    
    # Find the best pair
    best_pair = None
    best_score = -1
    
    for forward in forward_primers:
        for reverse in reverse_primers:
            # Calculate product size
            if forward.get("position") is not None and reverse.get("position") is not None:
                product_size = reverse["position"] - forward["position"]
                
                # Only consider pairs with reasonable product size
                if product_size <= 0 or product_size > 1000:
                    continue
                
                # Calculate compatibility score (similar Tm, no cross dimers)
                tm_diff = abs(forward["properties"]["tm"] - reverse["properties"]["tm"])
                compatibility_score = 1.0 - (tm_diff / 10)
                
                # Adjust score based on product size (prefer 100-300 bp)
                if 100 <= product_size <= 300:
                    size_factor = 1.0
                elif product_size < 100:
                    size_factor = product_size / 100
                else:  # > 300
                    size_factor = 1.0 - min(0.5, (product_size - 300) / 700)
                
                overall_score = compatibility_score * size_factor
                
                if overall_score > best_score:
                    best_score = overall_score
                    best_pair = {
                        "forward_primer": forward,
                        "reverse_primer": reverse,
                        "product_size": product_size,
                        "compatibility_score": compatibility_score
                    }
    
    # If no good pair found, just take the best primers
    if not best_pair:
        logger.warning("Could not find optimal primer pair, using best individual primers")
        return {
            "forward_primer": forward_primers[0],
            "reverse_primer": reverse_primers[0],
            "product_size": 150,  # Placeholder
            "compatibility_score": 0.5  # Placeholder
        }
    
    return best_pair