# assay_design/optimized_target_identification.py

import logging
import time
from typing import List, Dict, Any, Optional, Set
from collections import Counter
from Bio.SeqRecord import SeqRecord

logger = logging.getLogger(__name__)

def find_discriminative_kmers(
    inclusion_sequences: List[SeqRecord],
    exclusion_sequences: List[SeqRecord],
    kmer_size: int = 20,
    min_conservation: float = 0.8,
    max_sequences: int = 5,
    max_sequence_length: int = 2000,
) -> Dict[str, Any]:
    """
    Find conserved k-mers present in inclusion sequences but not in exclusion sequences.
    
    Args:
        inclusion_sequences: Sequences from target organisms
        exclusion_sequences: Sequences from non-target organisms
        kmer_size: Size of k-mers to analyze
        min_conservation: Minimum conservation level (0-1)
        max_sequences: Maximum number of sequences to process
        max_sequence_length: Maximum length of sequence to consider
        
    Returns:
        Dict containing marker information
    """
    start_time = time.time()
    logger.info(f"Finding discriminative k-mers of size {kmer_size}...")
    
    # Preprocess sequences to limit dataset size
    inc_seqs = preprocess_sequences(inclusion_sequences, max_sequences, max_sequence_length)
    exc_seqs = preprocess_sequences(exclusion_sequences, max_sequences, max_sequence_length)
    
    if not inc_seqs:
        return {"error": "No valid inclusion sequences after preprocessing"}
    
    logger.info(f"Analyzing {len(inc_seqs)} inclusion and {len(exc_seqs)} exclusion sequences")
    
    # Extract k-mers from inclusion sequences with counts
    inclusion_kmers = Counter()
    for seq in inc_seqs:
        seq_str = str(seq.seq).upper()
        for i in range(len(seq_str) - kmer_size + 1):
            kmer = seq_str[i:i+kmer_size]
            if 'N' not in kmer and '-' not in kmer:  # Skip k-mers with gaps or ambiguous bases
                inclusion_kmers[kmer] += 1
    
    # Extract k-mers from exclusion sequences
    exclusion_kmers = set()
    for seq in exc_seqs:
        seq_str = str(seq.seq).upper()
        for i in range(len(seq_str) - kmer_size + 1):
            kmer = seq_str[i:i+kmer_size]
            if 'N' not in kmer and '-' not in kmer:
                exclusion_kmers.add(kmer)
    
    # Find conserved k-mers specific to inclusion sequences
    conserved_specific_kmers = {}
    conservation_threshold = min_conservation * len(inc_seqs)
    
    for kmer, count in inclusion_kmers.items():
        if count >= conservation_threshold and kmer not in exclusion_kmers:
            conservation = count / len(inc_seqs)
            conserved_specific_kmers[kmer] = conservation
    
    logger.info(f"Found {len(conserved_specific_kmers)} conserved specific k-mers")
    
    # No discriminative k-mers found, try the best conserved k-mer
    if not conserved_specific_kmers:
        logger.info("No specific k-mers found, using most conserved k-mer")
        best_conserved = None
        best_conservation = 0
        
        for kmer, count in inclusion_kmers.items():
            conservation = count / len(inc_seqs)
            if conservation > best_conservation:
                best_conserved = kmer
                best_conservation = conservation
        
        if best_conserved:
            return {
                "marker_sequence": best_conserved,
                "marker_length": kmer_size,
                "conservation_score": best_conservation,
                "specificity_score": 0,
                "description": f"Conserved but non-specific marker (present in {best_conservation:.2f} of inclusion sequences)"
            }
        else:
            return {"error": "No suitable markers found"}
    
    # Find the best k-mer (highest conservation)
    best_kmer = max(conserved_specific_kmers.items(), key=lambda x: x[1])
    kmer, conservation = best_kmer
    
    # Check if we should extend the k-mer
    if kmer_size < 100:  # Only try extension for smaller k-mers
        logger.info(f"Extending best k-mer (conservation: {conservation:.2f})")
        extended_kmer = extend_kmer(kmer, inc_seqs, exc_seqs)
        if len(extended_kmer) > len(kmer):
            kmer = extended_kmer
    
    # Calculate specificity as 1 - (presence in exclusion / total exclusion)
    specificity = 1.0  # Fully specific
    
    elapsed_time = time.time() - start_time
    logger.info(f"Found marker in {elapsed_time:.2f} seconds")
    
    return {
        "marker_sequence": kmer,
        "marker_length": len(kmer),
        "conservation_score": conservation,
        "specificity_score": specificity,
        "description": f"Specific marker region (present in {conservation:.2f} of inclusion sequences, absent in exclusion)"
    }

def preprocess_sequences(
    sequences: List[SeqRecord], 
    max_sequences: int = 5, 
    max_length: int = 2000
) -> List[SeqRecord]:
    """
    Preprocess sequences to limit dataset size.
    
    Args:
        sequences: Input sequences
        max_sequences: Maximum number of sequences to keep
        max_length: Maximum length of each sequence
        
    Returns:
        Processed sequences
    """
    if not sequences:
        return []
    
    # Limit number of sequences
    if len(sequences) > max_sequences:
        logger.info(f"Limiting from {len(sequences)} to {max_sequences} sequences")
        sequences = sequences[:max_sequences]
    
    # Process each sequence
    result = []
    for seq in sequences:
        # Trim sequence if too long
        if len(seq.seq) > max_length:
            logger.info(f"Trimming sequence {seq.id} from {len(seq.seq)} to {max_length} bp")
            from Bio.SeqRecord import SeqRecord
            from Bio.Seq import Seq
            
            trimmed_seq = SeqRecord(
                Seq(str(seq.seq[:max_length])),
                id=seq.id,
                description=f"{seq.description} (trimmed)"
            )
            result.append(trimmed_seq)
        else:
            result.append(seq)
    
    return result

def extend_kmer(
    kmer: str, 
    inclusion_seqs: List[SeqRecord], 
    exclusion_seqs: List[SeqRecord],
    max_extension: int = 100,
    min_conservation: float = 0.7
) -> str:
    """
    Extend k-mer to create a longer marker sequence.
    
    Args:
        kmer: Starting k-mer sequence
        inclusion_seqs: Inclusion sequences
        exclusion_seqs: Exclusion sequences
        max_extension: Maximum extension length
        min_conservation: Minimum conservation for extension
        
    Returns:
        Extended marker sequence
    """
    # Convert exclusion sequences to strings for faster lookup
    exclusion_strs = [str(seq.seq).upper() for seq in exclusion_seqs]
    
    # Find positions of the k-mer in inclusion sequences
    positions = []
    for seq in inclusion_seqs:
        seq_str = str(seq.seq).upper()
        # Find all occurrences of k-mer
        pos = seq_str.find(kmer)
        while pos >= 0:
            positions.append((seq, pos))
            pos = seq_str.find(kmer, pos + 1)
    
    if not positions:
        return kmer
    
    # Start with the original k-mer
    extended = kmer
    
    # Try to extend to the left
    extension_count = 0
    left_pos = 0
    
    while extension_count < max_extension:
        left_pos -= 1
        extension_count += 1
        
        # Count bases at this position
        bases = Counter()
        valid_positions = 0
        
        for seq, pos in positions:
            if pos + left_pos >= 0:
                base = seq.seq[pos + left_pos].upper()
                if base not in 'N-':  # Skip gaps and ambiguous bases
                    bases[base] += 1
                    valid_positions += 1
        
        if valid_positions == 0:
            break
        
        # Find most common base
        if not bases:
            break
            
        common_base, count = bases.most_common(1)[0]
        conservation = count / valid_positions if valid_positions > 0 else 0
        
        # Check if extension is conserved enough
        if conservation >= min_conservation:
            # Check if extended sequence appears in exclusion
            test_extension = common_base + extended
            is_specific = all(test_extension not in exc_str for exc_str in exclusion_strs)
            
            if is_specific:
                extended = test_extension
            else:
                break  # Stop if extension loses specificity
        else:
            break
    
    # Try to extend to the right
    extension_count = 0
    right_pos = len(extended)
    
    while extension_count < max_extension:
        extension_count += 1
        
        # Count bases at this position
        bases = Counter()
        valid_positions = 0
        
        for seq, pos in positions:
            if pos + right_pos < len(seq.seq):
                base = seq.seq[pos + right_pos].upper()
                if base not in 'N-':
                    bases[base] += 1
                    valid_positions += 1
        
        if valid_positions == 0:
            break
        
        # Find most common base
        if not bases:
            break
            
        common_base, count = bases.most_common(1)[0]
        conservation = count / valid_positions if valid_positions > 0 else 0
        
        # Check if extension is conserved enough
        if conservation >= min_conservation:
            # Check if extended sequence appears in exclusion
            test_extension = extended + common_base
            is_specific = all(test_extension not in exc_str for exc_str in exclusion_strs)
            
            if is_specific:
                extended = test_extension
                right_pos += 1
            else:
                break  # Stop if extension loses specificity
        else:
            break
    
    return extended

def find_optimal_marker(
    inclusion_sequences: List[SeqRecord],
    exclusion_sequences: List[SeqRecord],
    timeout_seconds: int = 60
) -> Dict[str, Any]:
    """
    Find the optimal marker with timeout.
    
    Args:
        inclusion_sequences: Sequences from target organisms
        exclusion_sequences: Sequences from non-target organisms
        timeout_seconds: Maximum execution time in seconds
        
    Returns:
        Dict containing marker information
    """
    start_time = time.time()
    logger.info("Finding optimal marker with timeout...")
    
    # Try different k-mer sizes to optimize results
    best_result = None
    best_score = 0
    
    # Try k-mer sizes in this order (prioritize medium k-mers)
    kmer_sizes = [25, 20, 30, 15, 35]
    
    for kmer_size in kmer_sizes:
        # Check timeout
        if time.time() - start_time > timeout_seconds:
            logger.info(f"Timeout reached after {timeout_seconds} seconds")
            break
        
        try:
            result = find_discriminative_kmers(
                inclusion_sequences,
                exclusion_sequences,
                kmer_size=kmer_size
            )
            
            if "error" in result:
                continue
                
            # Calculate combined score (conservation * specificity * length_factor)
            length_factor = min(1.0, result.get("marker_length", 0) / 100)
            score = (
                result.get("conservation_score", 0) * 
                result.get("specificity_score", 0) * 
                length_factor
            )
            
            if score > best_score:
                best_score = score
                best_result = result
                
            # If we found a good marker, stop early
            if score > 0.8:
                logger.info(f"Found high-quality marker with score {score:.2f}")
                break
                
        except Exception as e:
            logger.error(f"Error with k-mer size {kmer_size}: {e}")
    
    if best_result:
        elapsed_time = time.time() - start_time
        logger.info(f"Marker identification completed in {elapsed_time:.2f} seconds")
        return best_result
    else:
        # Fallback to a simple strategy
        logger.info("No optimal marker found, using fallback strategy")
        return fallback_marker_strategy(inclusion_sequences)

def fallback_marker_strategy(sequences: List[SeqRecord]) -> Dict[str, Any]:
    """
    Fallback strategy when optimal marker identification fails.
    
    Args:
        sequences: Inclusion sequences
        
    Returns:
        Dict containing marker information
    """
    if not sequences:
        return {"error": "No sequences provided"}
    
    # Use a region from the first sequence
    seq = sequences[0]
    length = min(150, len(seq.seq))
    
    marker = str(seq.seq[:length])
    
    return {
        "marker_sequence": marker,
        "marker_length": length,
        "conservation_score": 1.0 / len(sequences),
        "specificity_score": 0.5,  # Unknown specificity
        "description": "Fallback marker (limited evaluation)"
    }